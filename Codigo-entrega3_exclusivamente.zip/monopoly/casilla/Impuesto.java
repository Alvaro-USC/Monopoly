package monopoly.casilla;

import monopoly.Valor;
import partida.Jugador;

import static monopoly.Juego.consola;

public class Impuesto extends Casilla {
    public Impuesto(String nombre, int posicion, float impuesto, Jugador duenho) {
        super(nombre, posicion, impuesto, duenho);
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {
        boolean solv = true;
        float toPay = getImpuesto();
        if (actual.getFortuna() < toPay) {
            solv = false;
            consola.imprimir("No eres solvente, vas a estar en negativo.");
        }
        actual.sumarGastos(toPay);
        Casilla parking = getTablero().encontrar_casilla("Parking");
        parking.sumarValor(toPay);
        consola.imprimir("El jugador paga " + Valor.formatear(toPay) + "€ en impuestos, que se depositan en el Parking.");
        monopoly.StatsTracker.getInstance().registrarPagoImpuesto(actual, toPay);
        return solv;
    }

    public String infoCasilla() {return "{ \n tipo: " + getTipo() + ", \n apagar: " + Valor.formatear(getImpuesto()) + "\n}";}
}