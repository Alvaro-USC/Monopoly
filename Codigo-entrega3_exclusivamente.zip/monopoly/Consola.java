package monopoly;

public interface Consola {
    void imprimir(String mensaje);

    String leer(String descripcion);
}